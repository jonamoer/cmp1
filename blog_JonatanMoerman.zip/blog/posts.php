
<?php require_once 'header.php';?>



<?require_once 'nav.php';?>

<div class="container">

  <div class="starter-template">
    <h1>Posts</h1>
    <p class="lead">Posts Pagina</p>
  </div>

</div><!-- /.container -->



<?php require_once 'footer.php';?>
